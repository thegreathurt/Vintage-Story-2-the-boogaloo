
# v0.3.4 - 2021-08-15 - Fixes and tweaks

## Bugfixes

* #177 - Red and brown clay bricks could not be fired in a kiln (Reported by TechRabbit)
* #172 - Brown clay needs now green clay as input
* #169 - For 1.15.3: Remove halite from drystone wall recycling recipes

## New features

* #127 - Stack up to 32 (was: 24) raw clay or clazed bricks per block
* #127 - Fire up to 16 (was: 12) raw clay or clazed bricks in a pit kiln

# v0.3.3 - 2021-08-02 - More Fixes

## Bugfixes

* #170 - Cannot fire raw glazed planters in pit kilns

# v0.3.2 - 2021-07-31 - Fixes for 1.15.3

## Bugfixes

* #166 - For 1.15.3: fix lapis, cinnabar and lead crushing

## New Features

* #165 - Add kimberlite stone and small stone bricks
* #160 - glazed bowls can be used for oil lamps
* #156 - add bamboo stack and roof piece recycling

# v0.3.1 - 2021-07-26 - Tweaks to the Clayed Release

## Bugfixes

* #161 - glazed bowls with meals held wrongly in TP (Reported by Cirdanoth)
* #159 - Tweak nugget crushing (add hematite, limonite, magnetite and pentlandite)
* #159 - Tweak ingot crushing: double the output of copper, gold and lead
* #158 - "Lapis lazuli" had no space in the name (Reported by Cirdanoth)
* #157 - Remove broken `game:lang/` patches (Reported by Lisabet)
* #154 - Cannot use glazed bowls with honey in recipes
* #153 - Reduce handbook clutter by grouping items (Reported by Craluminum)

## Balancing and Tweaking

* #163 - allow use of olivine for green clay

# v0.3.0 - 2021-07-16 - The Clayed Release

## Compatibility

The mod is now compatible with VS v1.15:

* Ceramics, pottery and patterns can now be placed on the ground
* Ceramics, pottery, patterns and glazed bricks must now be fired in a kiln
* You can stack raw or burnt glazed bricks on the ground
* Added some dye recipes based on metals
* Use `recipeGroup` to sep. building from recycling/transformation recipes
* Add recycling recipes for drystone blocks and fences

## New Features

* Craft flowerpots, planters and storage vessels from colored clay
* Single glazed bricks can now be put on a shelf or in a display case
* Recycle glazed brick and small stone brick blocks, stairs and slabs
* Recycle glass by smashing it with a hammer or pickaxe
* Added recipe for lead-based ruby gold glass (gold + tin + lead oxide)
* Added pentlandite crushing and powdered nickel
* Added crushed and powdered iron variants (limonite, magnetite, hematite)
* Slabs from small stonebricks and hardened clay can now be oriented horizontally/vertically

## Bugfixes

* Include missing files like LICENSE and README in the release archive
* Set correct stack sizes for colored and glazed planters, flowerpots and vessels

## Balancing and Tweaking

* Metal crushing recipes changed to match v1.15 outputs
* Disabled nugget crushing for metals that have non-compatible amounts in v1.15
* All glass colors are now based on metal ions and oxides
* `Red` components in glass recipes can always take any of the red color ingredients
* Allow crushing copper, gold and lead ingots to make up for lost nugget crushing

# v0.2.1 - 2021-06-10 - Tweaks for Glass

## Balancing and Tweaking

* Glass batches need 60% less ingredients, and 1/2 the burn time & fuel
* Allow converting Litharge back to Massicot
* Set the real galena => lead oxide conversion temperature (1000°)
* Optimized glazed planter & flowerpot: use 9 vs. 21 cubes & overlay textures instead of extra faces

## Bugfixes

* Add the missing "hardened clay slabs" => "blocks" recipe
* Fix recycling recipe for glazed bricks
* Fix recipe for combining clayshingle slabs into blocks

## Compatibility

* Glazed planters are now compatible with CarryCapacity

# v0.2.0 - 2021-06-03 - Glazing and Glassmaking

This version adds a new late-game mechanic for
creating glazes and colored glass, complete
with a detailed guide in the handbook.

## New features

* Create 15 different glass colors (called "frit")
* Create milky or clear glazes in 15 colors each
* Glaze bricks, bowls, flowerpots and planters
* Create and apply patterns to glazed flowerpots or planters
* Mix and smelt colored glass (in the existing VS colors)
* Build blocks, slabs and stairs from glazed bricks
* Saw hardened clay blocks in half to create slabs
* Create colored clay and bake it into hardened clay blocks

# v0.1.2 - 2021-05-13 - Add Missing Obsidian recipes

## Fixes

* Add missing recipe variants for obsidian small stone bricks, slabs and stairs (Thanx Lisabet!)

# v0.1.1 - 2021-05-12 - Obsidian tweaks

## Fixes

* Fix warning about removing `/textures` in polishedrockslab.json
* Add the omitted recipe for polishing slabs into obsidian stonebricks
* Tweak obsidian brick textures to be darker than the base rock

# v0.1.0 - 2021-05-11 - Small stone bricks

## New features

* Polish stonebricks into small stone bricks
* Craft stonebrick blocks, slabs and stairs with smaller bricks
* Polish obsidian into blocks and slabs

# v0.0.3 - 2021-05-03 - Shingle recipes

## Additional recipes

* Saw shingle blocks into slabs
* Combine two shingle slabs into full shingle blocks
* Combine three shingle slabs into shingle stairs
* Use a hammer or pickaxe to break down shingle blocks, slabs or stairs into shingles

# v0.0.2 - 2021-04-25 - Recipe fixes

## Fixes

* The recipe for transforming stone blocks or stairs into slabs have
the shovel now on the side (no longer on top) to be consistent
with all other "transforming" recipes that use a saw.

# v0.0.1 - 2021-03-21 - First Bricks Thrown

## New Features

### Block transformations

* Saw cobble, stonebrick and claybrick blocks into slabs
* Combine cobble slabs with clay into full cobble blocks
* Combine two clay or stone brick slabs with mortar into full brick blocks
* Combine two stonepath slabs into stonepath blocks
* Combine three stonepath slabs into stonepath stairs
* You can craft chimneys also with mortar (to be consistent with other brick blocks)
* You can craft brick stairs consistent to cobble stairs (edge on the top-left corner)

### Recycling

* Use a hammer or pickaxe to break down cobble blocks or slabs into rocks
* Use a saw to saw clay or stone brick blocks, slabs, stairs or chimneys back into bricks
* Use a shovel to break stonepath blocks or stairs back into stonepath slabs

#### Note:

The vanilla clay brick blocks, slabs, stairs and chimneys have yields inconsistent with f.i. cobble stairs.
In addition, brick slabs need 5 bricks, compared to cobble slabs which only need 3 stones.
Thus the recycling of the various brick blocks yields different brick counts than recycling rock based blocks.

**This version does not touch the vanilla recipes, but it is planned to adjust the brick recipes
to be consistent with the cobble variants.**
