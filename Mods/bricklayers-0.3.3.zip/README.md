# Bricklayers

"Bricks and stones may break bones."

  <u>**This is an alpha release and work in progress!**</u>

This Vintage Story mod adds new blocks and recipes to the
game, as well as a new late-game play mechanic:

## Glazed Ceramics & Glassmaking

Create colored glazings and coat bricks, planters, flowerpots and bowls
with them. You can even apply patterns to glazed planters and
flowerpots.

The glass colors can then also be used to smelt colored glass.

The whole process adds a new workflow: you will need automation,
a lot of resources and time, but the results will be rare and
wonderful items for your collection, to decorate or trade with others.

## Colored Clay

* Craft different clay colors by combining clay with coloring agents.
* Craft pottery (planters, flowerpots and storage vessels) from colored clay

## New Blocks & Recipes

This mod also adds usefull recipes to recycle or transform blocks.
And there are new stone brick blocks and colors.

You can combine slabs into full blocks, saw full blocks into slabs,
and recycle blocks back into stones or bricks.

You can divide stonepath blocks or stonepath stairs into slabs,
or combine stonepath slabs back into full stonepath blocks.

There are new colored clay blocks for you to use in building and chiseling.
And you can use a saw to create hardened clay slabs from hardened clay blocks.

## More Information

You can find more information and pretty pictures at our [Wiki](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/home).

Please see our [Roadmap](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Roadmap) for
information about planned features.

We hope you enjoy our work.

~Phiwa & Tels

# Download

* The mod From [Official Vintage Story ModDB](https://mods.vintagestory.at/show/mod/329)
* The source code can be found on [Gitlab](https://gitlab.com/codesmiths/vs_bricklayers/-/releases)

# Installation

This mod should work in existing worlds. If in doubt, please create a new world.

  <u>**Make a backup of your savegame and world before trying this mod!**</u>

# Features

## New Mechanic: Glazing and Glassmaking

* Crush, grind and mix items into Frit (glass colors)
* Sinter (bake) and grind Frits, add them to glazing bases to create glazes
* Glaze bricks, bowls, flowerpots and even planters to color them
* Create and apply patterns to planters and flowerpots
* Form new brick blocks from glazed clay bricks

## New Blocks & Items

* Polish stonebricks into small stone bricks
* Craft stonebrick blocks, slabs and stairs with smaller bricks
* Polish obsidian into blocks and slabs

## Block transformations

* Saw cobble, stonebrick, claybrick and shingle blocks into slabs
* Combine cobble slabs with clay into full cobble blocks
* Combine two clay or stone brick slabs with mortar into full brick blocks
* Combine two stonepath slabs into stonepath blocks
* Combine two shingle slabs into full shingle blocks
* Combine three stonepath slabs into stonepath stairs
* Combine three shingle slabs into shingle stairs
* You can craft chimneys also with mortar (to be consistent with other brick blocks)
* You can craft brick stairs consistent with cobble stairs (edge on the top-left corner)


## Recycling

* Use a hammer or pickaxe to break down cobble blocks or slabs into rocks
* Use a hammer or pickaxe to break down shingle blocks, slabs or stairs into shingles
* Use a saw to saw clay or stone brick blocks, slabs, stairs or chimneys back into bricks
* Use a saw to saw shingle blocks, slabs or stairs back into shingles
* Use a shovel to break stonepath blocks or stairs back into stonepath slabs

**This version does not touch vanilla recipes.**

# Languages

* English (100%)
* German (100%)

If you would like to translate this mod into other languages, please [contact us](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Contact).

# Known issues

The vanilla clay brick blocks, slabs, stairs and chimneys have yields inconsistent with f.i. cobble stairs.
In addition, brick slabs need 5 bricks, compared to cobble slabs which only need 3 stones.
Thus the recycling of the various brick blocks yields different brick counts than recycling rock based blocks.

**This version does not touch vanilla recipes, but it is planned to adjust the brick recipes
to be consistent with the cobble variants.**

# Changes and Roadmap

Please see the [Changelog](Changelog) for the changes in the latest release.

The full [Roadmap](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Roadmap) page contains all the planned or possible features.

If you have any ideas, or know about features that already done in another mod, then we
love [to hear from you](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Contact).

# Signature key

All our releases are signed using PGP (GnuPG) and their integrity can be verified by using the public key as published
[on the wiki](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Signing-key).

